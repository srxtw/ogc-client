import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  build: {
    sourcemap: true,
  },
  resolve: {
    alias: {
      // Point directly to the browser bundle which has all the initialization code
      '@camptocamp/ogc-client': path.resolve(__dirname, 'node_modules/@camptocamp/ogc-client/dist/index.js'),
      // Force parse-xml to use the ESM build instead of the browser CJS build
      '@rgrove/parse-xml': path.resolve(__dirname, 'node_modules/@rgrove/parse-xml/dist/index.js'),
    },
  },
  optimizeDeps: {
    exclude: ['@camptocamp/ogc-client'],
  },
})
