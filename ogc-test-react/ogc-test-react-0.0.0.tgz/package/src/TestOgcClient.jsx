import { useState } from 'react';
import { 
  setFetchOptions, 
  resetFetchOptions,
  enableFallbackWithoutWorker,
  initWorkerFetchOptionsSync,
  WmtsEndpoint,
  clearCache,
} from '@camptocamp/ogc-client';

// Initialize worker fetch options synchronization
initWorkerFetchOptionsSync();

function TestOgcClient() {
  const [message, setMessage] = useState('Click the button to test');

  const testExports = async () => {
    try {
      // These work fine
                  const sampleOptions = {
                headers: {
                    Authorization: 'mwc test'
                }
            };
      clearCache();
      console.log('✅ setFetchOptions:', setFetchOptions);
      console.log('✅ resetFetchOptions:', resetFetchOptions);
      enableFallbackWithoutWorker();
      setFetchOptions(sampleOptions);
      // Try to set fetch options
      //setFetchOptions({ headers: { 'X-Test': 'test' } });
      console.log('✅ setFetchOptions called successfully');
               let wmtsUrl = 'https://mrdata.usgs.gov/mapcache/wmts/'
            let endpoint = await new WmtsEndpoint(wmtsUrl).isReady();
            console.log('✅ wmts called successfully');
      
      // CRITICAL BUG EXPLANATION:
      // The callback registration in worker/index.ts (line 110) NEVER RUNS!
      
      setMessage(`🐛 CRITICAL BUG: Worker Module Not Imported!

The Real Issue:
- src/worker/index.ts line 110 calls: setFetchOptionsUpdateCallback(...)
- This registers a callback to sync fetch options to the worker
- BUT worker/index.ts is NOT exported from src/index.ts
- So when you use the official npm package, worker/index.ts never executes!
- The callback registration NEVER happens!
- Worker never receives fetch option updates!

What you imported:
✅ WmtsEndpoint (from src/index.ts)
✅ setFetchOptions (from src/index.ts)
❌ worker/index.ts (NOT imported, NOT executed)

The consequence:
- setFetchOptions() works, but only updates the main thread
- The worker module code never runs
- No callback is registered
- Worker uses default fetch options forever!

Why this is hard to debug:
- No errors thrown
- setFetchOptions() appears to work
- The bug is silent - worker just uses wrong credentials
- Bundlers tree-shake out the entire worker module

To verify in DevTools:
1. F12 → Sources tab
2. Search for 'setFetchOptionsUpdateCallback'
3. You'll find the function definition
4. But NOT the registration call from worker/index.ts line 110!`);
      
      
    } catch (error) {
      setMessage(`ERROR: ${error.message}`);
    }
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h1>🔍 OGC Client Export Test</h1>
      
      <button 
        onClick={testExports} 
        style={{ 
          padding: '15px 30px', 
          fontSize: '18px',
          cursor: 'pointer',
          backgroundColor: '#007bff',
          color: 'white',
          border: 'none',
          borderRadius: '5px',
          fontWeight: 'bold'
        }}
      >
        Test Package Exports
      </button>
      
      <pre style={{ 
        marginTop: '20px', 
        padding: '20px', 
        background: '#f8f9fa',
        border: '1px solid #dee2e6',
        borderRadius: '5px',
        whiteSpace: 'pre-wrap',
        fontSize: '14px',
        lineHeight: '1.6'
      }}>
        {message}
      </pre>
      
      <div style={{ 
        marginTop: '30px', 
        padding: '20px', 
        background: '#fff3cd', 
        border: '2px solid #ffc107', 
        borderRadius: '5px' 
      }}>
        <h2>🐛 Debugging Instructions</h2>
        <ol style={{ textAlign: 'left', lineHeight: '1.8' }}>
          <li>Open Browser DevTools (F12)</li>
          <li>Go to the <strong>Sources</strong> tab</li>
          <li>Search for <code>setFetchOptionsUpdateCallback</code></li>
          <li>You'll find it ONLY in the source files under <code>node_modules</code>, not in the bundled code</li>
          <li>Try setting a breakpoint - it won't work in your client code!</li>
          <li>The function is tree-shaken out because it's not exported</li>
        </ol>
        
        <h3>📝 Root Cause</h3>
        <p>
          In <code>src/index.ts</code>, only these functions are exported from <code>http-utils.ts</code>:
        </p>
        <pre style={{ background: '#fff', padding: '10px', borderRadius: '3px' }}>
{`export {
  sharedFetch,
  setFetchOptions,
  resetFetchOptions,
  // setFetchOptionsUpdateCallback is MISSING!
} from './shared/http-utils.js';`}
        </pre>
      </div>
    </div>
  );
}

export default TestOgcClient;
